﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Institude_project
{
    public partial class FEES : Form
    {
        private PrintDocument printDocument = new PrintDocument();
        private static int invoiceCounter = 1001;  // Starting Invoice Number
        public FEES()
        {
            InitializeComponent();
            fillcombo();
            InitializeComponent();
            printDocument.PrintPage += new PrintPageEventHandler(PrintDocument_PrintPage);
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        public void fillcombo()
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();
                    string Sql = "SELECT * from subTbl";
                     MySqlCommand cmd = new MySqlCommand(Sql,conn);

                    using (MySqlDataReader myreader = cmd.ExecuteReader())
                    {
                        while (myreader.Read())
                        {
                            string sname = myreader.GetString(1);
                            comboBox2.Items.Add(sname);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void displayBtn_Click(object sender, EventArgs e)
        {
            string invoiceDetails = GenerateInvoice();
            richTextBox1.Text = invoiceDetails; // Show in RichTextBox

            PrintPreviewDialog printPreviewDialog = new PrintPreviewDialog();
            printPreviewDialog.Document = printDocument;
            printPreviewDialog.ShowDialog();
        }
        private string GenerateInvoiceNumber()
        {
            string datePart = DateTime.Now.ToString("yyyyMMdd"); // Format: YYYYMMDD
            string uniqueNumber = datePart + invoiceCounter.ToString();  // Combine date with counter
            invoiceCounter++; // Increment the counter for the next invoice
            return uniqueNumber;
        }

        // Function to Generate Invoice Details
        private string GenerateInvoice()
        {
            // Invoice Details
            string instituteName = "Elite Institute";
            string address = "123 Main St, City, Country";
            string phone = "Phone: 0123-456789";
            string invoiceTitle = "Monthly Payment Invoice";
            string invoiceDate = "Date: " + DateTime.Now.ToString("dd/MM/yyyy");

            // Generate Invoice Number
            string invoiceNumber = GenerateInvoiceNumber();
            string invoiceNumDisplay = "Invoice #: " + invoiceNumber;

            // Dynamic Data (e.g., from a database)
            string studentName = "John Doe"; // Replace with actual student name
            string course = "Software Engineering";
            string amount = "Rs. 20,000";
            string dueDate = "Due Date: 10/10/2024";

            // Building Invoice Text
            return $"{instituteName}\n{address}\n{phone}\n\n{invoiceTitle}\n{invoiceDate}\n{invoiceNumDisplay}\n\n" +
                   $"Student Name: {studentName}\nCourse: {course}\nAmount Due: {amount}\n{dueDate}\n\n" +
                   $"Thank you for your payment!";
        }
        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            // Get the text from RichTextBox for printing
            string invoiceText = richTextBox1.Text;
            Font bodyFont = new Font("Arial", 12);
            Brush brush = Brushes.Black;

            // Draw the text on the print document
            e.Graphics.DrawString(invoiceText, bodyFont, brush, new PointF(50, 100));

            // If you need more pages
            e.HasMorePages = false;
        }
    }
}
