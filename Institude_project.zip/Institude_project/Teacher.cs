﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Institude_project
{
    public partial class Teacher : Form
    {
        public event Action TeacherAdded; // Declare the event
        public Teacher()
        {
            InitializeComponent();
        }

        private void saveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("INSERT INTO teacherTbl VALUES(@teacherid,@teachername,@gender,@phone)", conn);
                    cmd.Parameters.AddWithValue("@teacherid", int.Parse(teacheridTxt.Text)); //convert string into int
                    cmd.Parameters.AddWithValue("@teachername", teachernameTxt.Text);
                    cmd.Parameters.AddWithValue("@gender", genderTxt.Text);
                    cmd.Parameters.AddWithValue("@phone", phoneTxt.Text);

                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Record saved successfully ", "save", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    TeacherAdded?.Invoke();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("SELECT * FROM teacherTbl", conn);
                    MySqlDataAdapter dataAdapter = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    dataAdapter.Fill(dt);
                    dataGridView1.DataSource = dt;



                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("UPDATE teacherTbl SET teacherid=@teacherid,teachername=@teachername,gender=@gender,phone=@phone where teacherid=@teacherid", conn);
                    cmd.Parameters.AddWithValue("@teacherid", int.Parse(teacheridTxt.Text)); //convert string into int
                    cmd.Parameters.AddWithValue("@teachername", teachernameTxt.Text);
                    cmd.Parameters.AddWithValue("@gender", genderTxt.Text);
                    cmd.Parameters.AddWithValue("@phone", phoneTxt.Text);

                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Record update successfully ", "update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("DELETE from teacherTbl WHERE teacherid=@teacherid", conn);
                    cmd.Parameters.AddWithValue("@teacherid", int.Parse(teacheridTxt.Text)); //convert string into int

                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Record Deleted successfully ", "delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void newBtn_Click(object sender, EventArgs e)
        {
            teacheridTxt.Text = string.Empty;
            teachernameTxt.Text = string.Empty;
            genderTxt.Text = string.Empty;
            phoneTxt.Text = string.Empty;
        }

        private void displayBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("SELECT * FROM teacherTbl", conn);
                    MySqlDataAdapter dataAdapter = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    dataAdapter.Fill(dt);
                    dataGridView1.DataSource = dt;



                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
