﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Institude_project
{
    public partial class attendance : Form
    {
        string status;
        public attendance()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            status = "present";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            status = "absent";
        }

        private void dateTxt_ValueChanged(object sender, EventArgs e)
        {
            dateTxt.CustomFormat = "dd/MM/yyyy";
        }

        private void dateTxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {

                dateTxt.CustomFormat = " ";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    MySqlCommand cmd = new MySqlCommand("SELECT studentname FROM studentTbl where studentid=@studentid", conn);
                    cmd.Parameters.AddWithValue("@studentid", int.Parse(studentidTxt.Text));
                   
                    MySqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        studentnameTxt.Text = reader.GetString(0);
                    }
                    else
                    {
                        MessageBox.Show("No student add under this id ", "add", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }




                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void studentidTxt_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void saveBtn_Click(object sender, EventArgs e)
        {

            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();

                    if (string.IsNullOrEmpty(status))
                    {
                        MessageBox.Show("Please select attendance status (Present/Absent)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return; // Stop execution if status is not set
                    }
                    else
                    {
                        // Use parameterized queries to prevent SQL injection
                        MySqlCommand cmd = new MySqlCommand("INSERT INTO attendanceTbl VALUES(@studentid,@studentname,@date,@status)", conn);
                        cmd.Parameters.AddWithValue("@studentid", int.Parse(studentidTxt.Text)); //convert string into int
                        cmd.Parameters.AddWithValue("@studentname", studentnameTxt.Text);
                        cmd.Parameters.AddWithValue("@date", dateTxt.Value);
                        cmd.Parameters.AddWithValue("@status", status);

                        cmd.ExecuteNonQuery();
                        conn.Close();
                        MessageBox.Show("Record saved successfully ", "save", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                   
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("SELECT * FROM attendanceTbl", conn);
                    MySqlDataAdapter dataAdapter = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    dataAdapter.Fill(dt);
                    dataGridView1.DataSource = dt;



                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();
                    if (string.IsNullOrEmpty(status))
                    {
                        MessageBox.Show("Please select attendance status (Present/Absent)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return; // Stop execution if status is not set
                    }
                    else
                    {

                        // Use parameterized queries to prevent SQL injection
                        MySqlCommand cmd = new MySqlCommand("UPDATE attendanceTbl SET attendancedate=@date,status=@status where studentid=@studentid", conn);
                        cmd.Parameters.AddWithValue("@studentid", int.Parse(studentidTxt.Text)); //convert string into int
                        cmd.Parameters.AddWithValue("@date", dateTxt.Value);
                        cmd.Parameters.AddWithValue("@status", status);

                        cmd.ExecuteNonQuery();
                        conn.Close();
                        MessageBox.Show("Record update successfully ", "update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("DELETE from attendanceTbl WHERE studentid=@studentid", conn);
                    cmd.Parameters.AddWithValue("@studentid", int.Parse(studentidTxt.Text)); //convert string into int

                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Record Deleted successfully ", "delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void newBtn_Click(object sender, EventArgs e)
        {
            studentidTxt.Text = string.Empty;
            studentnameTxt.Text = string.Empty;
            status = string.Empty;
        }

        private void displayBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("SELECT * FROM attendanceTbl", conn);
                    MySqlDataAdapter dataAdapter = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    dataAdapter.Fill(dt);
                    dataGridView1.DataSource = dt;



                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
