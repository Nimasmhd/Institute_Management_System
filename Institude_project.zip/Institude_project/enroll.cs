﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Institude_project
{
   
    public partial class enroll : Form
    {
        public event Action EnrollAdded;
        public enroll()
        {
            InitializeComponent();
        }

        private void dateTxt_ValueChanged(object sender, EventArgs e)
        {
            dateTxt.CustomFormat = "dd/MM/yyyy";
        }

        private void dateTxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {

                dateTxt.CustomFormat = " ";
            }
        }

        private void saveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("INSERT INTO enrollTbl VALUES(@eid,@studentname,@section,@enrolldate)", conn);
                    cmd.Parameters.AddWithValue("@eid", int.Parse(eidTxt.Text)); //convert string into int
                    cmd.Parameters.AddWithValue("@studentname", studentnameTxt.Text);
                    cmd.Parameters.AddWithValue("@section", sectionTxt.Text);
                    cmd.Parameters.AddWithValue("@enrolldate", dateTxt.Value);

                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Record saved successfully ", "save", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    EnrollAdded?.Invoke();
    }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("SELECT * FROM enrollTbl", conn);
                    MySqlDataAdapter dataAdapter = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    dataAdapter.Fill(dt);
                    dataGridView1.DataSource = dt;



                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("UPDATE enrollTbl SET eid=@eid,studentname=@studentname,section=@section,enrolldate=@enrolldate where eid=@eid", conn);
                    cmd.Parameters.AddWithValue("@eid", int.Parse(eidTxt.Text)); //convert string into int
                    cmd.Parameters.AddWithValue("@studentname", studentnameTxt.Text);
                    cmd.Parameters.AddWithValue("@section", sectionTxt.Text);
                    cmd.Parameters.AddWithValue("@enrolldate", dateTxt.Value);

                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Record update successfully ", "update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("DELETE from enrollTbl WHERE eid=@eid", conn);
                    cmd.Parameters.AddWithValue("@eid", int.Parse(eidTxt.Text)); //convert string into int

                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Record Deleted successfully ", "delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void newBtn_Click(object sender, EventArgs e)
        {
            eidTxt.Text = string.Empty;
            studentnameTxt.Text = string.Empty;
            sectionTxt.Text = string.Empty;
        }

        private void displayBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("SELECT * FROM enrollTbl", conn);
                    MySqlDataAdapter dataAdapter = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    dataAdapter.Fill(dt);
                    dataGridView1.DataSource = dt;



                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
