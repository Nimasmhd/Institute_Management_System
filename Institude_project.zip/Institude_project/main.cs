﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Institude_project
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            student student = new student();
            student.StudentAdded += () => display();
            student.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            subject subject = new subject();
            subject.SubjectAdded += () => display2();
            subject.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Teacher teacher = new Teacher();
            teacher.TeacherAdded += () => display1();
            teacher.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            section section = new section();
            section.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            enroll enroll = new enroll();
            enroll.EnrollAdded += () => display3(); //event to automatic refresh
            enroll.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            attendance attendance = new attendance();
            attendance.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void main_Load(object sender, EventArgs e)
        {
            timer1.Start();
            display();
            display1();
            display2();
            display3();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label5.Text = DateTime.Now.ToLongTimeString();
            label6.Text = DateTime.Now.ToLongDateString();
        }

        private void display()
        {
            MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password=");

            try
            {
                conn.Open(); // Open the connection before executing the query

                MySqlCommand cmd = new MySqlCommand("SELECT count(*) FROM studenttbl", conn);

                Int32 count = Convert.ToInt32(cmd.ExecuteScalar());

                if (count > 0)
                {
                    label11.Text = count.ToString();
                }
                else
                {
                    label11.Text = "00";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                conn.Close(); // Ensure the connection is closed after execution
            }
        }

        private void display1()
        {
            MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password=");

            try
            {
                conn.Open(); // Open the connection before executing the query

                MySqlCommand cmd = new MySqlCommand("SELECT count(*) FROM teachertbl", conn);

                Int32 count = Convert.ToInt32(cmd.ExecuteScalar());

                label12.Text = count > 0 ? count.ToString() : "00";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                conn.Close(); // Ensure the connection is closed after execution
            }
        }


        private void display2()
        {
            MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password=");

            try
            {
                conn.Open(); // Open the connection before executing the query

                MySqlCommand cmd = new MySqlCommand("SELECT count(*) FROM subtbl", conn);

                Int32 count = Convert.ToInt32(cmd.ExecuteScalar());

                label13.Text = count > 0 ? count.ToString() : "00";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                conn.Close(); // Ensure the connection is closed after execution
            }
        }

        private void display3()
        {
            MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password=");

            try
            {
                conn.Open(); // Open the connection before executing the query

                MySqlCommand cmd = new MySqlCommand("SELECT count(*) FROM enrolltbl", conn);

                Int32 count = Convert.ToInt32(cmd.ExecuteScalar());

                label14.Text = count > 0 ? count.ToString() : "00";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                conn.Close(); // Ensure the connection is closed after execution
            }
        }

        private void panel10_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FEES fEES = new FEES();
            fEES.Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to logout?",
                                         "Confirm Logout",
                                         MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                // Close the main form
                this.Close();
                student student = new student();
                student.Close(); 
                Teacher teacher = new Teacher();
                teacher.Close();
                subject subject = new subject();
                subject.Close();


           
            }
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }
    }
}
