﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace Institude_project
{
    public partial class student : Form
    {
        public event Action StudentAdded;
        public student()
        {
            InitializeComponent();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dateTxt.CustomFormat = "dd/MM/yyyy";
        }

        private void dateTimePicker1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back) {

                dateTxt.CustomFormat = " ";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();
                

                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("INSERT INTO studentTbl VALUES(@studentid,@studentname,@dob,@gender,@phone,@email)", conn);
                    cmd.Parameters.AddWithValue("@studentid", int.Parse(stusentidTxt.Text)); //convert string into int
                    cmd.Parameters.AddWithValue("@studentname", studentnameTxt.Text);
                    cmd.Parameters.AddWithValue("@dob", dateTxt.Value); //mention date from above method datTimePicker
                    cmd.Parameters.AddWithValue("@gender",genderTxt.Text);
                    cmd.Parameters.AddWithValue("@phone",phoneTxt.Text);
                    cmd.Parameters.AddWithValue("@email",emailTxt.Text);

                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Record saved successfully ","save",MessageBoxButtons.OK,MessageBoxIcon.Information);

                    StudentAdded?.Invoke();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("SELECT * FROM studentTbl", conn);
                    MySqlDataAdapter dataAdapter = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    dataAdapter.Fill(dt);
                    dataGridView1.DataSource = dt;
                    
                    
                   
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }

        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("UPDATE studentTbl SET studentid=@studentid,studentname=@studentname,dob=@dob,gender=@gender,phone=@phone,email=@email where studentid=@studentid", conn);
                    cmd.Parameters.AddWithValue("@studentid", int.Parse(stusentidTxt.Text)); //convert string into int
                    cmd.Parameters.AddWithValue("@studentname", studentnameTxt.Text);
                    cmd.Parameters.AddWithValue("@dob", dateTxt.Value); //mention date from above method datTimePicker
                    cmd.Parameters.AddWithValue("@gender", genderTxt.Text);
                    cmd.Parameters.AddWithValue("@phone", phoneTxt.Text);
                    cmd.Parameters.AddWithValue("@email", emailTxt.Text);

                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Record update successfully ", "update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("DELETE from studentTbl WHERE studentid=@studentid", conn);
                    cmd.Parameters.AddWithValue("@studentid", int.Parse(stusentidTxt.Text)); //convert string into int
                   
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Record Deleted successfully ", "delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void newBtn_Click(object sender, EventArgs e)
        {
            stusentidTxt.Text = string.Empty;
            studentnameTxt.Text = string.Empty;
            genderTxt.Text = string.Empty;
            phoneTxt.Text = string.Empty;
            emailTxt.Text = string.Empty;
        }

        private void displayBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("SELECT * FROM studentTbl", conn);
                    MySqlDataAdapter dataAdapter = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    dataAdapter.Fill(dt);
                    dataGridView1.DataSource = dt;



                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void student_Load(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("SELECT * FROM studentTbl", conn);
                    MySqlDataAdapter dataAdapter = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    dataAdapter.Fill(dt);
                    dataGridView1.DataSource = dt;



                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
