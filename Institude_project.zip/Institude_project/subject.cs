﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Institude_project
{
    public partial class subject : Form
    {
        public event Action SubjectAdded;
        public subject()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void saveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("INSERT INTO subTbl VALUES(@subjectid,@subjectname)", conn);
                    cmd.Parameters.AddWithValue("@subjectid", int.Parse(subjectIdTxt.Text)); //convert string into int
                    cmd.Parameters.AddWithValue("@subjectname", subjectNameTxt.Text);
                  

                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Record saved successfully ", "save", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    SubjectAdded?.Invoke();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("SELECT * FROM subTbl", conn);
                    MySqlDataAdapter dataAdapter = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    dataAdapter.Fill(dt);
                    dataGridView1.DataSource = dt;



                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("UPDATE subTbl SET subjectid=@subjectid,subjectname=@subjectname where subjectid=@subjectid", conn);
                    cmd.Parameters.AddWithValue("@subjectid", int.Parse(subjectIdTxt.Text)); //convert string into int
                    cmd.Parameters.AddWithValue("@subjectname", subjectNameTxt.Text);
                   

                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Record update successfully ", "update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("DELETE from subTbl WHERE subjectid=@subjectid", conn);
                    cmd.Parameters.AddWithValue("@subjectid", int.Parse(subjectIdTxt.Text)); //convert string into int

                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Record Deleted successfully ", "delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void newBtn_Click(object sender, EventArgs e)
        {
            subjectIdTxt.Text = string.Empty;
            subjectNameTxt.Text = string.Empty ;
        }

        private void displayBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost; user=root; database=institutedb; password="))
                {
                    conn.Open();


                    // Use parameterized queries to prevent SQL injection
                    MySqlCommand cmd = new MySqlCommand("SELECT * FROM subTbl", conn);
                    MySqlDataAdapter dataAdapter = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    dataAdapter.Fill(dt);
                    dataGridView1.DataSource = dt;



                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
