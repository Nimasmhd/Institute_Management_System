-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2024 at 01:08 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `institutedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendancetbl`
--

CREATE TABLE `attendancetbl` (
  `studentid` int(11) NOT NULL,
  `studentname` varchar(50) NOT NULL,
  `attendancedate` datetime DEFAULT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendancetbl`
--

INSERT INTO `attendancetbl` (`studentid`, `studentname`, `attendancedate`, `status`) VALUES
(112, 'case', '2024-09-13 11:04:27', 'absent'),
(112, 'case', '2024-09-20 14:45:22', 'present'),
(113, 'Rahul', '2024-09-25 09:12:16', 'present'),
(111, 'user01', '2024-09-25 10:50:52', 'present');

-- --------------------------------------------------------

--
-- Table structure for table `enrolltbl`
--

CREATE TABLE `enrolltbl` (
  `Eid` int(11) NOT NULL,
  `studentname` varchar(50) NOT NULL,
  `section` varchar(50) NOT NULL,
  `enrolldate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `enrolltbl`
--

INSERT INTO `enrolltbl` (`Eid`, `studentname`, `section`, `enrolldate`) VALUES
(115, 'user01', '05', '2024-09-25 10:51:36');

-- --------------------------------------------------------

--
-- Table structure for table `logintbl`
--

CREATE TABLE `logintbl` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logintbl`
--

INSERT INTO `logintbl` (`id`, `username`, `password`) VALUES
(1, 'admin', '123'),
(2, 'nimas', '12345'),
(5, 'nimas', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `sectiontbl`
--

CREATE TABLE `sectiontbl` (
  `sectionid` int(11) NOT NULL,
  `studentname` varchar(50) NOT NULL,
  `section` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sectiontbl`
--

INSERT INTO `sectiontbl` (`sectionid`, `studentname`, `section`) VALUES
(1, 'sdd', 'sss'),
(2, 'ghg', 'fyf');

-- --------------------------------------------------------

--
-- Table structure for table `studenttbl`
--

CREATE TABLE `studenttbl` (
  `studentID` int(11) NOT NULL,
  `studentName` varchar(50) NOT NULL,
  `dob` datetime NOT NULL,
  `gender` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `studenttbl`
--

INSERT INTO `studenttbl` (`studentID`, `studentName`, `dob`, `gender`, `phone`, `email`) VALUES
(111, 'user01', '2024-09-19 10:42:31', 'male', '0775465213', 'user@gmail.com'),
(112, 'case', '2024-09-20 09:54:09', 'male', '12222', '1sss'),
(113, 'Rahul', '2024-09-17 09:11:13', 'male', '13232', 'knc');

-- --------------------------------------------------------

--
-- Table structure for table `subtbl`
--

CREATE TABLE `subtbl` (
  `subjectId` int(11) NOT NULL,
  `subjectName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subtbl`
--

INSERT INTO `subtbl` (`subjectId`, `subjectName`) VALUES
(3, 'commerce'),
(11, 'history'),
(12, 'history'),
(13, 'Science');

-- --------------------------------------------------------

--
-- Table structure for table `teachertbl`
--

CREATE TABLE `teachertbl` (
  `teacherId` int(11) NOT NULL,
  `teacherName` varchar(50) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Phone` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachertbl`
--

INSERT INTO `teachertbl` (`teacherId`, `teacherName`, `Gender`, `Phone`) VALUES
(1, 'dss', 'ddd', '1222'),
(2, 'dddf', 'male', '1222222'),
(112, 'ddxx', 'ddd', 'ddd'),
(113, 'nimas', 'male', '0222');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendancetbl`
--
ALTER TABLE `attendancetbl`
  ADD KEY `studentid` (`studentid`);

--
-- Indexes for table `enrolltbl`
--
ALTER TABLE `enrolltbl`
  ADD PRIMARY KEY (`Eid`);

--
-- Indexes for table `logintbl`
--
ALTER TABLE `logintbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sectiontbl`
--
ALTER TABLE `sectiontbl`
  ADD PRIMARY KEY (`sectionid`);

--
-- Indexes for table `studenttbl`
--
ALTER TABLE `studenttbl`
  ADD PRIMARY KEY (`studentID`);

--
-- Indexes for table `subtbl`
--
ALTER TABLE `subtbl`
  ADD PRIMARY KEY (`subjectId`);

--
-- Indexes for table `teachertbl`
--
ALTER TABLE `teachertbl`
  ADD PRIMARY KEY (`teacherId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `logintbl`
--
ALTER TABLE `logintbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendancetbl`
--
ALTER TABLE `attendancetbl`
  ADD CONSTRAINT `attendancetbl_ibfk_1` FOREIGN KEY (`studentid`) REFERENCES `studenttbl` (`studentID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
